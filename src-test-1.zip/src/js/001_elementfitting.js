/**
 * FITTING SOME ELEMENTS IN PLACE
 * @summary Some JS calcs to fit elemenst nicely in place
 * @author Cliff Crerar
 * Created at     : 2018-06-05 22:07:04 
 * Last modified  : 2018-06-05 22:25:25
 */

// GET HIGHT OF TEXT LOGO